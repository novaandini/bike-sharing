import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

def sum_orders_df():
    day_df = pd.read_csv('dashboard/day_data.csv')
    day_df['dteday'] = pd.to_datetime(day_df['dteday'])
    days_orders_df = day_df.resample(rule='Q', on='dteday').agg({
        "instant": "nunique",
        "cnt": "sum"
    })
    days_orders_df.index = days_orders_df.index.to_period('Q').strftime('Q%q %Y')
    days_orders_df = days_orders_df.reset_index()
    days_orders_df.rename(columns={
        "instant": "Banyak Data Transaksi",
        "cnt": "Banyak Sepeda"
    }, inplace=True)

    st.subheader("Total sepeda yang disewakan per kuartal")
    fig, ax = plt.subplots(figsize=(16, 8))
    ax.plot(
        days_orders_df["dteday"],
        days_orders_df["Banyak Sepeda"],
        marker='o', 
        linewidth=2,
        color="#000000"
    )
    ax.tick_params(axis='y', labelsize=20)
    ax.tick_params(axis='x', labelsize=15)
    
    st.pyplot(fig)

def getDataByWeather(weatherSelection):
    weather_dict = {
        "Cerah": 1,
        "Berkabut": 2,
        "Hujan": 3,
        "Badai": 4
    }

    weatherSelection = weather_dict.get(weatherSelection, 0)

    day_df = pd.read_csv('dashboard/day_data.csv')
    day_df['dteday'] = pd.to_datetime(day_df['dteday'])
    
    df_filtered = day_df[day_df["weathersit"] == weatherSelection]

    if not df_filtered.empty:
    # Membuat line chart dengan Seaborn
        fig, ax = plt.subplots(figsize=(8, 5))

        day_df["month_year"] = day_df["dteday"].dt.to_period("M")

        df_grouped = day_df[day_df["weathersit"]==weatherSelection].groupby(["month_year", "weathersit"])["cnt"].sum().reset_index()

        # Konversi period ke string agar bisa dipakai sebagai label di grafik
        df_grouped["month_year"] = df_grouped["month_year"].astype(str)

        # Plot line chart dengan Seaborn
        fig, ax = plt.subplots(figsize=(10, 5))
        sns.lineplot(data=df_grouped, x="month_year", y="cnt", hue="weathersit", marker="o", ax=ax)

        
        ax.set_title("Jumlah Customer Per Hari Berdasarkan Cuaca")
        ax.set_xlabel("Tanggal")
        ax.set_ylabel("Jumlah Customer")
        ax.tick_params(axis='x', rotation=45)
        ax.grid(True)
        
        # Menampilkan grafik di Streamlit
        st.pyplot(fig)
    else:
        st.warning("Tidak ada data untuk cuaca yang dipilih.")


with st.sidebar:
    weatherSelection = st.selectbox(
        label="Pilih Cuaca",
        options=('Cerah', 'Berkabut', 'Hujan', 'Badai')
    )

if (weatherSelection == 'Cerah'):
    st.header('Tren pengguna layanan Bike Sharing pada Cuaca Cerah :sparkles:')
    getDataByWeather('Cerah')
elif (weatherSelection == 'Berkabut'):
    st.header('Tren pengguna layanan Bike Sharing pada Cuaca Berkabut :sparkles:')
    getDataByWeather('Berkabut')
elif (weatherSelection == 'Badai'):
    st.header('Tren pengguna layanan Bike Sharing pada Cuaca Badai :sparkles:')
    getDataByWeather('Badai')
elif (weatherSelection == 'Hujan'):
    st.header('Tren pengguna layanan Bike Sharing pada Cuaca Hujan :sparkles:')
    getDataByWeather('Hujan')
else:
    st.error('This is an error', icon="🚨")


