## Setup Environment - Shell/Terminal

```sh
mkdir bike-sharing
cd bike-sharing
pipenv install
pip install -r requirements.txt
```
## Run steamlit app
```sh
streamlit run dashboard/dashboard.py
```
